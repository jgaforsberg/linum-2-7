#ifndef LIB_COMP_H
#define LIB_COMP_H


int e_resistance(float orig_resistance, float *res_array);
float find_largest_res(float resistance);
int power_of_ten(float resistance);

#endif
