#ifndef LIB_RES_H
#define LIB_RES_H


float calc_resistance(int count, char conn, float *array);

#endif
