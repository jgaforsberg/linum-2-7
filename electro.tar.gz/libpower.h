#ifndef LIB_POW_H
#define LIB_POW_H


#include <math.h>
float calc_power_r(float volt, float resistance);
float calc_power_i(float volt, float current);

#endif
